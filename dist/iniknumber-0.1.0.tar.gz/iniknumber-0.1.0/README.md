# NIK Checker

A Python package to parse and validate NIK codes.

## Installation

```bash
pip install iniknumber
